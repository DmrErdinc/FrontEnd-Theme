// Sepet ve favori işlemleri için yardımcı fonksiyonlar
const CartManager = {
    // Sepet verilerini localStorage'dan al
    getCart: function() {
        return JSON.parse(localStorage.getItem('cart')) || [];
    },

    // Favori verilerini localStorage'dan al
    getFavorites: function() {
        return JSON.parse(localStorage.getItem('favorites')) || [];
    },

    // Ürün detaylarını localStorage'dan al
    getProductDetails: function(productId) {
        const products = JSON.parse(localStorage.getItem('products')) || [];
        return products.find(p => p.id === productId);
    },

    // Sepete ürün ekle
    addToCart: function(productId) {
        const product = this.getProductDetails(productId);
        if (!product) {
            console.error('Ürün bulunamadı:', productId);
            return;
        }

        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        const existingItem = cart.find(item => item.id === productId);

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                id: productId,
                name: product.name,
                price: product.price,
                image: product.image,
                quantity: 1
            });
        }

        localStorage.setItem('cart', JSON.stringify(cart));
        this.updateCartCount();
        this.showNotification('Ürün sepete eklendi!');
    },

    // Sepetten ürün çıkar
    removeFromCart: function(productId) {
        let cart = this.getCart();
        cart = cart.filter(item => item.id !== productId);
        localStorage.setItem('cart', JSON.stringify(cart));
        this.updateCartCount();
    },

    // Favorilere ürün ekle
    addToFavorites: function(productId) {
        let favorites = this.getFavorites();
        let product = this.getProductDetails(productId);
        
        if (!product) {
            console.error('Ürün bulunamadı:', productId);
            return false;
        }

        if (!favorites.includes(productId)) {
            favorites.push(productId);
            localStorage.setItem('favorites', JSON.stringify(favorites));
            this.updateFavoriteCount();
            return true;
        }
        return false;
    },

    // Favorilerden ürün çıkar
    removeFromFavorites: function(productId) {
        let favorites = this.getFavorites();
        favorites = favorites.filter(id => id !== productId);
        localStorage.setItem('favorites', JSON.stringify(favorites));
        this.updateFavoriteCount();
    },

    // Sepet sayısını güncelle
    updateCartCount: function() {
        let cart = this.getCart();
        let totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        $('.fa-shopping-cart').next('.badge').text(totalItems);
    },

    // Favori sayısını güncelle
    updateFavoriteCount: function() {
        let favorites = this.getFavorites();
        $('.fa-heart').next('.badge').text(favorites.length);
    },

    // Sayfa yüklendiğinde sayaçları güncelle
    initialize: function() {
        this.updateCartCount();
        this.updateFavoriteCount();
    },

    showNotification: function(message) {
        // Bu fonksiyonun içeriği, bildirim gösterme işlemlerini içermelidir.
        // Bu örnekte, bildirim gösterme işlemleri için console.log kullanılmıştır.
        console.log(message);
    }
};

// Sayfa yüklendiğinde çalışacak kodlar
$(document).ready(function() {
    // CartManager'ı başlat
    CartManager.initialize();

    // Sepet ikonuna tıklandığında
    $('.fa-shopping-cart').parent().click(function(e) {
        e.preventDefault();
        window.location.href = 'cart.html';
    });

    // Favori ikonuna tıklandığında
    $('.fa-heart').parent().click(function(e) {
        e.preventDefault();
        window.location.href = 'favorites.html';
    });

    // İletişim butonlarına tıklandığında sayfanın en altına kaydır
    $('a[href="#contact"]').click(function(e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $('.container-fluid.bg-dark.text-secondary').offset().top
        }, 1000);
    });

    // Sepete ekle butonu
    $('.add-to-cart').click(function(e) {
        e.preventDefault();
        var productId = $(this).data('id');
        var quantity = $('.quantity input').val() || 1;
        if (CartManager.addToCart(productId, parseInt(quantity))) {
            alert('Ürün sepete eklendi!');
        } else {
            alert('Ürün eklenirken bir hata oluştu!');
        }
    });

    // Sepetten çıkar butonu
    $('.remove-from-cart').click(function() {
        var productId = $(this).data('id');
        CartManager.removeFromCart(productId);
        $(this).closest('tr').fadeOut(300, function() {
            $(this).remove();
        });
    });

    // Favorilere ekle butonu
    $('.add-to-favorite').click(function() {
        var productId = $(this).data('id');
        $(this).toggleClass('btn-danger');
        if ($(this).hasClass('btn-danger')) {
            if (CartManager.addToFavorites(productId)) {
                alert('Ürün favorilere eklendi!');
            } else {
                alert('Ürün favorilere eklenirken bir hata oluştu!');
            }
        } else {
            CartManager.removeFromFavorites(productId);
            alert('Ürün favorilerden çıkarıldı!');
        }
    });

    // Favorilerden çıkar butonu
    $('.remove-favorite').click(function() {
        var productId = $(this).data('id');
        CartManager.removeFromFavorites(productId);
        $(this).closest('.col-lg-4').fadeOut(300, function() {
            $(this).remove();
            // Eğer favori kalmadıysa mesaj göster
            if (CartManager.getFavorites().length === 0) {
                $('.card-body').html('<div class="text-center py-5"><h5>Favori ürününüz bulunmamaktadır.</h5><a href="shop.html" class="btn btn-primary mt-3">Alışverişe Başla</a></div>');
            }
        });
    });

    // Miktar artırma/azaltma
    $('.btn-plus').click(function() {
        var input = $(this).closest('.quantity').find('input');
        input.val(parseInt(input.val()) + 1);
    });

    $('.btn-minus').click(function() {
        var input = $(this).closest('.quantity').find('input');
        if (parseInt(input.val()) > 1) {
            input.val(parseInt(input.val()) - 1);
        }
    });
}); 