// Ürünleri localStorage'dan al ve göster
function displayProducts() {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    const productContainer = $('.row.px-xl-5');
    
    if (products.length === 0) {
        productContainer.html('<div class="col-12 text-center"><h3>Henüz ürün bulunmamaktadır.</h3></div>');
        return;
    }

    productContainer.empty();
    
    products.forEach(product => {
        productContainer.append(`
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="product-item bg-light mb-4">
                    <div class="product-img position-relative overflow-hidden">
                        <img class="img-fluid w-100" src="${product.image}" alt="${product.name}">
                    </div>
                    <div class="text-center py-4">
                        <a class="h6 text-decoration-none text-truncate" href="product-detail.html?id=${product.id}">${product.name}</a>
                        <div class="d-flex align-items-center justify-content-center mt-2">
                            <h5>${product.price.toFixed(2)} TL</h5>
                        </div>
                        <div class="d-flex align-items-center justify-content-center mb-1">
                            <small class="fa fa-star text-primary mr-1"></small>
                            <small class="fa fa-star text-primary mr-1"></small>
                            <small class="fa fa-star text-primary mr-1"></small>
                            <small class="fa fa-star text-primary mr-1"></small>
                            <small class="fa fa-star-half-alt text-primary mr-1"></small>
                            <small>(99)</small>
                        </div>
                        <div class="d-flex align-items-center justify-content-center">
                            <a class="btn btn-outline-dark mr-2 add-to-cart" href="#" data-id="${product.id}">
                                <i class="fa fa-shopping-cart text-primary mr-1"></i>Sepete Ekle
                            </a>
                            <a class="btn btn-outline-dark add-to-favorites" href="#" data-id="${product.id}">
                                <i class="fa fa-heart text-primary mr-1"></i>Favori
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        `);
    });
}

// Sayfa yüklendiğinde ürünleri göster
$(document).ready(function() {
    displayProducts();
}); 