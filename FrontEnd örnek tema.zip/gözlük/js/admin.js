// Admin bilgileri
const ADMIN_CREDENTIALS = {
    username: 'admin',
    password: 'admin123'
};

// Ürün yönetimi için yardımcı fonksiyonlar
const ProductManager = {
    // Ürünleri localStorage'dan al
    getProducts: function() {
        return JSON.parse(localStorage.getItem('products')) || [];
    },

    // Ürünleri localStorage'a kaydet
    saveProducts: function(products) {
        localStorage.setItem('products', JSON.stringify(products));
    },

    // Yeni ürün ekle
    addProduct: function(product) {
        let products = this.getProducts();
        product.id = products.length + 1; // Basit bir ID oluşturma
        products.push(product);
        this.saveProducts(products);
        this.updateProductList();
    },

    // Ürün güncelle
    updateProduct: function(productId, updatedProduct) {
        let products = this.getProducts();
        let index = products.findIndex(p => p.id === productId);
        if (index !== -1) {
            products[index] = { ...products[index], ...updatedProduct };
            this.saveProducts(products);
            this.updateProductList();
        }
    },

    // Ürün sil
    deleteProduct: function(productId) {
        let products = this.getProducts();
        products = products.filter(p => p.id !== productId);
        this.saveProducts(products);
        this.updateProductList();
    },

    // Ürün listesini güncelle
    updateProductList: function() {
        let products = this.getProducts();
        let tbody = $('#productList');
        tbody.empty();

        products.forEach(product => {
            tbody.append(`
                <tr>
                    <td>${product.id}</td>
                    <td>${product.name}</td>
                    <td>${product.price} TL</td>
                    <td>${product.stock}</td>
                    <td>
                        <button class="btn btn-sm btn-primary edit-product" data-id="${product.id}">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger delete-product" data-id="${product.id}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `);
        });
    }
};

// Sayfa yüklendiğinde çalışacak kodlar
$(document).ready(function() {
    // Admin girişi kontrolü
    if (localStorage.getItem('adminLoggedIn') === 'true') {
        $('#adminLoginForm').hide();
        $('#adminPanel').show();
        ProductManager.updateProductList();
    }

    // Admin giriş formu
    $('#adminLoginForm').submit(function(e) {
        e.preventDefault();
        let username = $('#username').val();
        let password = $('#password').val();

        if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
            localStorage.setItem('adminLoggedIn', 'true');
            $('#adminLoginForm').hide();
            $('#adminPanel').show();
            ProductManager.updateProductList();
        } else {
            alert('Hatalı kullanıcı adı veya şifre!');
        }
    });

    // Yeni ürün ekleme formu
    $('#addProductForm').submit(function(e) {
        e.preventDefault();
        let product = {
            name: $('#productName').val(),
            price: parseFloat($('#productPrice').val()),
            stock: parseInt($('#productStock').val()),
            image: $('#productImage').val(),
            description: $('#productDescription').val()
        };

        ProductManager.addProduct(product);
        this.reset();
        alert('Ürün başarıyla eklendi!');
    });

    // Ürün silme
    $(document).on('click', '.delete-product', function() {
        if (confirm('Bu ürünü silmek istediğinizden emin misiniz?')) {
            let productId = $(this).data('id');
            ProductManager.deleteProduct(productId);
            alert('Ürün başarıyla silindi!');
        }
    });

    // Ürün düzenleme
    $(document).on('click', '.edit-product', function() {
        let productId = $(this).data('id');
        let products = ProductManager.getProducts();
        let product = products.find(p => p.id === productId);

        if (product) {
            $('#productName').val(product.name);
            $('#productPrice').val(product.price);
            $('#productStock').val(product.stock);
            $('#productImage').val(product.image);
            $('#productDescription').val(product.description);

            // Form submit olayını güncelle
            $('#addProductForm').off('submit').submit(function(e) {
                e.preventDefault();
                let updatedProduct = {
                    name: $('#productName').val(),
                    price: parseFloat($('#productPrice').val()),
                    stock: parseInt($('#productStock').val()),
                    image: $('#productImage').val(),
                    description: $('#productDescription').val()
                };

                ProductManager.updateProduct(productId, updatedProduct);
                this.reset();
                alert('Ürün başarıyla güncellendi!');

                // Form submit olayını eski haline getir
                $('#addProductForm').off('submit').submit(function(e) {
                    e.preventDefault();
                    let product = {
                        name: $('#productName').val(),
                        price: parseFloat($('#productPrice').val()),
                        stock: parseInt($('#productStock').val()),
                        image: $('#productImage').val(),
                        description: $('#productDescription').val()
                    };

                    ProductManager.addProduct(product);
                    this.reset();
                    alert('Ürün başarıyla eklendi!');
                });
            });
        }
    });
}); 